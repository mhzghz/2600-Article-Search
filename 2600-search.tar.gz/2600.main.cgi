#!/usr/bin/perl

# GBPPR Total Information Awareness // GBPPR Advanced Development Projects
#

# Setup
#
select STDOUT;
$| = 1;

# Print MIME
#
print "Content-type:text/html\n\n";

# Draw me a web page
#
print <<EOF;
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<html>
<head>
<title>2600 Magazine Article &amp; Text Search</title>
</head>
<body bgcolor="#D3D3D3" text="#000000" link="blue">
<font face="Helvetica">

<center>
<table border="10" cellpadding="10">
<tr>
<td bgcolor="#A3A3A3"><font size="12" face="Helvetica" color="#82007C"><b><i>2600 Magazine</i> Article &amp; Text Search</b></font></td>
</tr>
<tr>
<td align="center" bgcolor="#A3A3A3"><b>A Service of GBPPR Total Information Awareness</b></td>
</tr>
</table>
</center>

<br>
<br>
<br>

<form action="./2600.cgi" method="post">

<center>
<table border="0">
<tr><td><b>Enter the Text/Word to Search For :</b></td><td><input type="text" name="search" size="20" value=""></td></tr>
<tr><td><b>&nbsp;Match Case?</b> <input type="radio" name="case" value="YES"> Yes <input type="radio" name="case" value="NO" checked> No</td></tr>
<tr><td><b>Line Expand?</b> <input type="radio" name="line" value="YES"> Yes <input type="radio" name="line" value="NO" checked> No</td></tr>

<tr><td><b>Line Wrap?</b> <select name="wrap">
<option>160</option>
<option>180</option>
<option>200</option>
<option>220</option>
<option selected>240</option>
<option>260</option>
<option>280</option>
<option>300</option>
<option>600</option>
</select></td></tr>

</table>

<br>
<br>

<table border="2" cellpadding="10">
<tr>
<p>Press <b>Submit</b> to see an example.</p>
<td bgcolor="#3240A8"><input type="submit" value="Submit"></td>
<td bgcolor="#3240A8"><input type="reset" value="Clear"></td>
</tr>
</table>
</center>
</form>

<blockquote>
<ul>
<li>Includes OCR data from issues of <a href="http://www.gbppr.net/2600"><i>2600 Magazine</i></a> and WhisperAI transcripts of <a href="http://www.gbppr.net/2600/oth"><i>Off The Hook</i></a> episodes and <a href="http://www.gbppr.net/2600/hope">Hackers on Planet Earth</a> presentations.</li>
<li>This is still kinda experimental and may give weird results if the OCR/WhisperAI didn't turn out right.</li>
<li>The HOPE videos are arranged by YouTube ID, as that's easier to work with via command line utils. (any starting '-' are removed)</li>
<li>Acronyms and computer/hacker slang tend to mess up AI translations, so be creative with your search terms.</li>
<li>TODO: Link directly to page, article, or timestamp on OTH and HOPE - subtract 60 secs or so</li>
</ul>
</blockquote>

</font>
</body>
</html>
EOF
