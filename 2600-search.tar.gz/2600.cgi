#!/usr/bin/perl
#
# GBPPR Total Information Awareness // GBPPR Advanced Development Projects
#
# Requires GNU fold
# Requires 'aha' by Alexander Matthes - Convert ANSI escape sequences to HTML
# sudo apt install aha
# Make sure it is installed under /usr/bin/aha or change path

# Setup
#
select STDOUT;
$| = 1;
use CGI::Carp qw(fatalsToBrowser);

# Print MIME
#
print "Content-type:text/html\n\n";

# Read environment
#
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
  ($name, $value) = split(/=/, $pair);
  $value =~ tr/+/ /;
  $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
  $FORM{$name} = $value;
}

$search = $FORM{'search'};
$case   = $FORM{'case'};
$line   = $FORM{'line'};
$wrap   = $FORM{'wrap'};

# Clean up user input data
#
$search =~ tr/A-Za-z0-9 ,()-.+=_\/\:\;&//csd;
$case   =~ tr/A-Z//csd;
$line   =~ tr/A-Z//csd;
$wrap   =~ tr/0-9//csd;

# Case sensitive search, pass -i option to grep
if ($case eq "YES") {
  $opt1 = "";
}
elsif ($case eq "NO") {
  $opt1 = "-i";
}

# Line expand search, pass -C1 option to grep
if ($line eq "YES") {
  $opt2 = "-C1";
}
elsif ($line eq "NO") {
  $opt2 = "";
}

# 2600/data-date.txt contains the date of the search database data.
open(my $FILE, '<', '2600/data-date.txt') or die "Could not open '2600/data-date.txt': $!";
   $data_date = <$FILE>;
   chomp $data_date;
close $FILE;

print "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 3.2//EN\">".
      "<html>".
      "<head>".
      "<title>Search Results</title>".
	  "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n".
      "</head>".
      "<body bgcolor=\"#D3D3D3\" text=\"#000000\" link=\"blue\">".
	  "<font face=\"Helvetica\">\n".
      "<center>".
      "<h1>Search Results</h1>".
      "</center>".
	  "<blockquote>\n".
	  "<b>Search String:</b> <font color=\"red\"><tt><b>$search</b></tt></font><br>\n".
	  "<b>Case Sensitive:</b> <font color=\"green\"><tt>$case</tt></font><br>\n".
      "<b>Line Wrap:</b> <font color=\"green\"><tt>$wrap</tt></font><br>\n".
	  "<b>Database Date:</b> <font color=\"green\"><tt>$data_date</tt></font><br>\n".
	  "<p><i>This is still kinda experimental and may give weird results if the OCR/WhisperAI didn't turn out right.</i></p>\n".
      "</blockquote>\n";

	  my $size = length($search);
	  if ($size <= 1 || $size > 30) {
        print "<font color=\"red\"><b>SEARCH TERMS LIMITED TO 2-30 CHARACTERS: <tt>A-Za-z0-9 ,()-.+=_\/\:\;</tt></b></font>\n";
        print "&nbsp;&nbsp;&nbsp;&nbsp;Using <tt>linux</tt> as an example.\n";
        $search = "linux";
      }

	  print "<center>\n";
	  print "<HR size=\"20\" align=center noshade color=\"#0091C9\">\n";
	  print "<p><font size=\"+4\"><a href=\"http://www.gbppr.net/2600\" target=\"_blank\"><b><i>2600 Magazine</i></b></a></font></p>\n";
      print "<HR size=\"20\" align=center noshade color=\"#F3CF1D\">\n";
	  print "</center>\n";
      print "<table border=\"3\" cellpadding=\"8\"><tr><td bgcolor=\"#CFCFCF\">\n";
      print "<pre>\n";
	  system("/usr/bin/grep --color=always $opt1 $opt2 '$search' 2600/2600* | /usr/bin/fold -s -w $wrap | /usr/bin/aha -n | sed -e 's/2600\\///g'");
      print "</pre>\n";
      print "</td></tr></table>\n";

	  print "<center>\n";
      print "<HR size=\"20\" align=center noshade color=\"#0091C9\">\n";
	  print "<p><font size=\"+4\"><a href=\"http://www.gbppr.net/2600/oth\" target=\"_blank\"><b><i>Off The Hook</i></b></a></font></p>\n";
      print "<HR size=\"20\" align=center noshade color=\"#F3CF1D\">\n";
      print "</center>\n";
      print "<table border=\"3\" cellpadding=\"8\"><tr><td bgcolor=\"#CFCFCF\">\n";
	  print "<pre>\n";
	  system("/usr/bin/grep --color=always $opt1 $opt2 '$search' 2600/Off* | /usr/bin/fold -s -w $wrap | /usr/bin/aha -n | sed -e 's/2600\\///g'");
      print "</pre>\n";
      print "<ul>\n";
      system("for i in `/usr/bin/grep $opt1 '$search' 2600/Off* | sed -e 's/2600\\///g' | awk -F: '{print \$1}' | awk '{print \$4}' | sed -e 's/-//g' | uniq`; do /usr/bin/grep \$i 2600/audio-list.txt | uniq; done");
	  print "</ul>\n";
      print "</td></tr></table>\n"; 

      print "<center>\n";
      print "<HR size=\"20\" align=center noshade color=\"#0091C9\">\n";
	  print "<p><font size=\"+4\"><a href=\"http://www.gbppr.net/2600/hope\" target=\"_blank\"><b>Hackers on Planet Earth</b></a></font></p>\n";
      print "<HR size=\"20\" align=center noshade color=\"#F3CF1D\">\n";
      print "</center>\n";
      print "<table border=\"3\" cellpadding=\"8\"><tr><td bgcolor=\"#CFCFCF\">\n";
	  print "<pre>\n";
	  system("/usr/bin/grep --color=always $opt1 $opt2 '$search' 2600/HOPE* | /usr/bin/fold -s -w $wrap | /usr/bin/aha -n | sed -e 's/2600\\///g'");
	  print "</pre>\n";
      
	  print "<ul>\n";
	  system("for i in `/usr/bin/grep $opt1 '$search' 2600/HOPE* | sed -e 's/2600\\///g' | awk -F: '{print \$1}' | awk '{print \$2}' | uniq`; do echo \"<tt>YouTube ID <a href=\"http://www.gbppr.net/2600/hope/transcripts/\$i.txt\" target=\"_blank\">\$i:</tt>\" && /usr/bin/grep \$i 2600/video-list.txt | uniq | /usr/bin/grep -v \"AI Transcript\" && echo \"<p></p>\"; done");
      print "</ul>\n";
      print "</td></tr></table>\n";


	  print "<br><br><br><center><b>Search Complete!</b></center></font></body></html>";
